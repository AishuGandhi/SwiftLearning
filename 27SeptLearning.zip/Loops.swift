let array = [1,2,3,4,5,6]
print("\(array)")

for num in array{
  print("Result:\(num * 2)")
}
var x = 0
while x <= 3
{
  print("Called:\(x)")
  x += 1
}
